﻿using System;
using System.DirectoryServices;
using API.MODEL;


namespace API.ActiveDirectoryService
{
    public class ActiveDirectoryService
    {
        DirectorySearcher directorySearcher;
        DirectoryEntry Ldap;
        UserService usuario;        
        

        private readonly string adPath = AdConfigurationManager.LDAP;
        string generateNewPWD = string.Empty;

        private DirectoryEntry getADConnection()
        {
            try
            {

                Ldap = new DirectoryEntry(adPath, AdConfigurationManager.AdUserService, AdConfigurationManager.AdPwdService);
                
                return Ldap;
            }
            catch (Exception )
            {
                throw;
            }

        }

        public string ResetPwd(string nome)
        {
            try
            {
                
                directorySearcher = new DirectorySearcher(getADConnection());

                directorySearcher.Filter = "(SAMAccountName=" + nome + ")";
                SearchResult _sr = directorySearcher.FindOne();
                var _name = _sr.Properties["displayname"][0].ToString();
                var _email = _sr.Properties["mail"][0].ToString();
                var _tipoConta = _sr.Properties["sAMAccountType"][0].ToString();


                usuario = new UserService(_name, _email,_tipoConta);

                if (_sr != null && usuario !=null)
                {
                    DirectoryEntry userEntry = _sr.GetDirectoryEntry();

                    if (userEntry != null)
                    {
                        generateNewPWD = "digi@" + nome + DateTime.Now.Year.ToString();
                        userEntry.Invoke("SetPassword", new object[] { generateNewPWD });
                        userEntry.CommitChanges();
                        userEntry.Properties["LockOutTime"].Value = 0;
                        userEntry.Close();
                    }
                }
               


            }
            catch (Exception)
            {

                throw;
            }
            return generateNewPWD;

        }


      
    }
}
