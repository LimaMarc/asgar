﻿

namespace API.MODEL
{
    public class UserService
    {
		private string _name;

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}


		private string _email;

		public string Email
		{
			get { return _email; }
			set { _email = value; }
		}

		private string _tipoConta;

		public string TipoConta
		{
			get { return _tipoConta; }
			set { _tipoConta = value; }
		}


		public UserService(string nome, string email,string tipoConta)
		{
			_name = nome;
			_email = email;
			_tipoConta = tipoConta;

		}

	}
}
