﻿using API.MODEL;
using Microsoft.AspNetCore.Mvc;


namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        
        ActiveDirectoryService.ActiveDirectoryService serviceAd;
        string erro = string.Empty;

        // GET: api/User/5
        [HttpGet("{userName}", Name = "Get")]
        public string Get(string userName)
        {
            try
            {
                
                serviceAd = new ActiveDirectoryService.ActiveDirectoryService();
                string newPassword = serviceAd.ResetPwd(userName);

                if (newPassword != "" && newPassword != null)
                {
                    return newPassword;
                }
            }
            catch (System.Exception error)
            {
                erro= error.Message.ToString();
            
            }

            return erro;
            
        }
        
    }
}
